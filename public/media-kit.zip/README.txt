SourceVerify Affiliate Media Kit
================================

Welcome — this kit contains everything you need to represent SourceVerify
accurately in your content.

Contents
--------

logos/
  sourceverify-horizontal.png   Horizontal wordmark (default)
  sourceverify-stacked.png      Stacked wordmark
  sourceverify-logomark.png     Symbol + wordmark composite
  sourceverify-symbol.svg       Symbol only (for light backgrounds)
  sourceverify-symbol-white.svg Symbol only (for dark backgrounds)

brand-reference-card.html       Colors, typography, logo usage, terminology
one-pager.html                  Product overview with key stats and capabilities

Both HTML files are print-ready — open in a browser and "Save as PDF"
to generate a shareable PDF.

Brand Essentials
----------------

Wordmark:  "Source" = coral (#F25D5D), "Verify" = dark blue (#010120)
Product:   SourceVerify (one word, capital S and V)
Contact:   team@sourceverify.ai
Website:   https://sourceverify.ai

Do
--
- Use the official logos from this kit
- Refer to the product as "SourceVerify"
- Use terms: verify, reference, source, unverified, needs review

Don't
-----
- Alter the logo colors, proportions, or layout
- Use "CitationCop" in promotional materials (internal codename only)
- Use terms: check, citation (when meaning source), invalid, wrong, bad, failed
- Make claims about accuracy beyond what we state (98%)
- Imply SourceVerify replaces peer review

Questions? team@sourceverify.ai
